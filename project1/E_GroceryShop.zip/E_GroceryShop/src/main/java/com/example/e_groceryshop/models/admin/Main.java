package com.example.e_groceryshop.models.admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XE","HR", "hr");
            statement = connection.createStatement();

            System.out.println("Enter Fruit Name");
            Scanner scanner = new Scanner(System.in);
            String frtName = scanner.nextLine();
            System.out.println("Enter Fruit Price");
            int frtPrice = scanner.nextInt();
            System.out.println("Enter Fruit Stock");
            int frtStock = scanner.nextInt();


            Fruits Apple = new Fruits(frtName,frtPrice,frtStock);
            FruitStock fruitStock = new FruitStock();
            fruitStock.addFruit(statement,Apple);
        } catch (ClassNotFoundException e) {
            System.out.println("Driver Class Not Found");
        } catch (SQLException e) {
            System.out.println("Connection Failed To Database");
        }
        finally {
            try {
                statement.close();
                connection.close();
            } catch (SQLException e) {
                System.out.println("Connection Not Closed");
            }
        }

    }
}
