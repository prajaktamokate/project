package com.example.e_groceryshop.models.admin;

public class Fruits {
    private String frtName;
    private int frtPrice;
    private int newStock;

    public Fruits(String frtName, int frtPrice, int newStock) {
        this.frtName = frtName.toUpperCase();
        this.frtPrice = frtPrice;
        this.newStock = newStock;
    }

    public String getFrtName() {
        return frtName;
    }

    public void setFrtName(String frtName) {
        this.frtName = frtName;
    }

    public int getFrtPrice() {
        return frtPrice;
    }

    public void setFrtPrice(int frtPrice) {
        this.frtPrice = frtPrice;
    }

    public int getNewStock() {
        return newStock;
    }

    public void setNewStock(int newStock) {
        this.newStock = newStock;
    }
}
