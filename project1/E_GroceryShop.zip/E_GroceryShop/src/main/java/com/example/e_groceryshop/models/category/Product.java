package com.example.e_groceryshop.models.category;

public abstract class Product {
    String productName;
    String productType;
    int productPrice;
    int productQty;
    int productTotalPrice;

    public Product(String productName, String productType, int productPrice, int productQty) {
        this.productName = productName.toUpperCase();
        this.productType = productType.toUpperCase();
        this.productPrice = productPrice;
        this.productQty = productQty;
        setProductTotalPrice();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductQty() {
        return productQty;
    }

    public void setProductQty(int productQty) {
        this.productQty = productQty;
        setProductTotalPrice();
    }

    public int getProductTotalPrice() {
        return productTotalPrice;
    }

    public void setProductTotalPrice() {
        this.productTotalPrice = getProductQty() * getProductPrice();
    }

    @Override
    public String toString() {
        return "Product{" +
                "productName='" + productName + '\'' +
                ", productType='" + productType + '\'' +
                ", productPrice=" + productPrice +
                ", productQty=" + productQty +
                ", productTotalPrice=" + productTotalPrice +
                '}';
    }

}
