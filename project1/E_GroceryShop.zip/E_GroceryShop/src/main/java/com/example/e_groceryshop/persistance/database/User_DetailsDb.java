package com.example.e_groceryshop.persistance.database;

import com.example.e_groceryshop.models.user.UserDetails;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class User_DetailsDb {
    public boolean isUser(String userName, String password){
        boolean userConfirm = false;
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        try {
            Query query = entityManager.createQuery("from UserDetails where email=:Email");
            query.setParameter("Email",userName);
            UserDetails user = (UserDetails) query.getSingleResult();
            if (user.getEmail().equals(userName) && user.getPassword().equals(password)){
                userConfirm  = true;
            }
        } catch (Exception e) {
            System.out.println("Query Not Executed");
        }finally {
            entityManager.getTransaction().commit();
            entityManager.close();
            entityManagerFactory.close();
        }
        return userConfirm;
    }
}
