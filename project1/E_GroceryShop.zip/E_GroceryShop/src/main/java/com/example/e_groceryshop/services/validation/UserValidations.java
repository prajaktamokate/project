package com.example.e_groceryshop.services.validation;

public class UserValidations {


    // validate first name
    public static boolean isFirstName( String firstName )
    {
        boolean correctVal = false;
        if (firstName.matches( "[a-zA-Z]*" ))
        {
            correctVal = true;
        }
        else
        {
            System.out.println("Invalid First Name!!!\n");
        }
        return correctVal;
    }

    // validate last name
    public static boolean isLastName( String lastName )
    {
        boolean correctVal = false;
        if (lastName.matches( "[a-zA-Z]*" ))
        {
            correctVal = true;
        }
        else
        {
            System.out.println("Invalid Last Name!!!\n");
        }
        return correctVal;
    }

    public static boolean isValidPassword(String password)
    {
        boolean isValid = true;
        if (password.length() < 8)
        {
            System.out.println("Password must be more than 8 characters in length.");
            isValid = false;
        }

        String upperCaseChars = "(.*[A-Z].*)";
        if (!password.matches(upperCaseChars ))
        {
            System.out.println("Password must have at least one uppercase character");
            isValid = false;
        }

        String lowerCaseChars = "(.*[a-z].*)";
        if (!password.matches(lowerCaseChars ))
        {
            System.out.println("Password must have at least one lowercase character");
            isValid = false;
        }

        String numbers = "(.*[0-9].*)";
        if (!password.matches(numbers ))
        {
            System.out.println("Password must have at least one number");
            isValid = false;
        }

        String specialChars = "(.*[@,#,$,%].*$)";
        if (!password.matches(specialChars ))
        {
            System.out.println("Password must have atleast one special character among @#$%");
            isValid = false;
        }

        return isValid;
    }
    public static boolean isValidPhone( String mobileNo )
    {
        boolean correctVal = false;
        if (mobileNo.matches( "[7-9][0-9]{9}"))
        {
            correctVal = true;
        }
        else
        {
            System.out.println("Invalid Mobile Number!!!\n");
        }
        return correctVal;
    }
    public static boolean isValidMail(String email){
        String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        boolean correctVal = false;
        if (email.matches(regex))
        {
            correctVal = true;
        }
        else
        {
            System.out.println("Invalid Email!!!\n");
        }
        return correctVal;
    }

    public static boolean isValidCity(String city)
    {
        if (city.matches( "[a-zA-Z]*" ))
        {
            return  true;
        }
        else
        {
            System.out.println("Invalid City Name!!!\n");
            return false;
        }
    }
    public  static boolean isValidPincode(String pin_code)
    {
        if (pin_code.length()==6 && pin_code.matches("[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}"))
        {
            return true;
        }
        else
        {
            System.out.println("Invalid Pin code!!!\n");
            return  false;
        }
    }
}
