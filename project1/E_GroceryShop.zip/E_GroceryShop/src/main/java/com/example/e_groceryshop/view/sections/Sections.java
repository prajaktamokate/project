package com.example.e_groceryshop.view.sections;

import com.example.e_groceryshop.models.category.Cart;
import com.example.e_groceryshop.models.category.Fruits;
import com.example.e_groceryshop.models.category.Product;
import com.example.e_groceryshop.models.category.Veggies;

import java.util.Scanner;

public class Sections {
    private static Cart<Product> cart = new Cart<>();
    private static int Total = 0;
    private static String repeat;
    private static String qty;
    private static String addCart;
    private static Scanner sc = new Scanner(System.in);
    public static void fruitSection(){
        do {
            System.out.println("1.Mango\t\t2.Apple\t\t3.Banana\t4.Orange");
            String selectFruit = sc.nextLine();
            switch (selectFruit) {
                case "1" : {
                    Product Mango = new Fruits("MANGO", "FRUIT", 400, 0);
                    System.out.println("How Many Kilo Mango You Want");
                    qty = sc.nextLine();
                    Mango.setProductQty(Integer.parseInt(qty));
                    System.out.println("Add To Cart");
                    addCart = sc.nextLine().toUpperCase();
                    if (addCart.equals("Y")) {
                        cart.addToCart(Mango);
                    }
                    break;
                }
                case "2" : {
                    Product Apple = new Fruits("APPLE", "FRUIT", 300, 0);
                    System.out.println("How Many Kilo Apple You Want");
                    qty = sc.nextLine();
                    Apple.setProductQty(Integer.parseInt(qty));
                    System.out.println("Add To Cart");
                    addCart = sc.nextLine().toUpperCase();
                    if (addCart.equals("Y")) {
                        cart.addToCart(Apple);
                    }
                    break;
                }
                case "3" : {
                    Product Banana = new Fruits("BANANA", "FRUIT", 60, 0);
                    System.out.println("How Many Dozen Banana You Want");
                    qty = sc.nextLine();
                    Banana.setProductQty(Integer.parseInt(qty));
                    System.out.println("Add To Cart");
                    addCart = sc.nextLine().toUpperCase();
                    if (addCart.equals("Y")) {
                        cart.addToCart(Banana);
                    }
                    break;
                }
                case "4" : {
                    Product Orange = new Fruits("ORANGE", "FRUIT", 100, 0);
                    System.out.println("How Many Kilo Orange You Want");
                    qty = sc.nextLine();
                    Orange.setProductQty(Integer.parseInt(qty));
                    System.out.println("Add To Cart");
                    addCart = sc.nextLine().toUpperCase();
                    if (addCart.equals("Y")) {
                        cart.addToCart(Orange);
                    }
                }
                default: {
                    System.out.println("Product Not Available");
                    break;
                }
            }
            System.out.println("Continue Buy Other Fruits");
            repeat = sc.nextLine().toUpperCase();
        } while (repeat.equals("Y"));
    }
    public static void vegetableSection(){
        do {
                System.out.println("1.Potato \t\t 2.Tomato \t\t 3.Onion \t 4.Eggplant \t\t 5.Green Pepper \t\t 6.Carrot \t 7.Red Papper \t\t 8.Garlic \t\t 9.Cauliflower \t 10.Broccoli");
                String selectVegi = sc.nextLine();
                switch (selectVegi) {
                    case "1" : {
                        Product Potato = new Veggies("POTATO", "VEGETABLE", 80, 0);
                        System.out.println("How Many Kilo Potato You Want");
                        qty = sc.nextLine();
                        Potato.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Potato);
                        }
                        break;
                    }
                    case "2" : {
                        Product Tomato = new Veggies("TOMATO", "VEGETABLE", 60, 0);
                        System.out.println("How Many Kilo Tomato You Want");
                        qty = sc.nextLine();
                        Tomato.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Tomato);
                        }
                        break;
                    }
                    case "3" : {
                        Product Onion = new Veggies("ONION", "VEGETABLE", 50, 0);
                        System.out.println("How Many Kilo Onion You Want");
                        qty = sc.nextLine();
                        Onion.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Onion);
                        }
                        break;
                    }
                    case "4" : {
                        Product Eggplant = new Veggies("EGGPLANT", "VEGETABLE", 40, 0);
                        System.out.println("How Many Kilo Eggplant You Want");
                        qty = sc.nextLine();
                        Eggplant.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Eggplant);
                        }
                        break;
                    }
                    case "5" : {
                        Product greenPepper = new Veggies("GREEN PAPER", "VEGETABLE", 80, 0);
                        System.out.println("How Many Kilo Green Pepper You Want");
                        qty = sc.nextLine();
                        greenPepper.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(greenPepper);
                        }
                        break;
                    }
                    case "6" : {
                        Product Carrot = new Veggies("CARROT", "VEGETABLE", 90, 0);
                        System.out.println("How Many Kilo Carrot You Want");
                        qty = sc.nextLine();
                        Carrot.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Carrot);
                        }
                        break;
                    }
                    case "7" : {
                        Product redPapper = new Veggies("RED PAPER", "VEGETABLE", 50, 0);
                        System.out.println("How Many Dozen Red Papper You Want");
                        qty = sc.nextLine();
                        redPapper.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(redPapper);
                        }
                        break;
                    }
                    case "8" : {
                        Product Garlic = new Veggies("EGGPLANT", "VEGETABLE", 40, 0);
                        System.out.println("How Many Kilo Garlic You Want");
                        qty = sc.nextLine();
                        Garlic.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Garlic);
                        }
                        break;
                    }
                    case "9" : {
                        Product Cauliflower = new Veggies("POTATO", "VEGETABLE", 80, 0);
                        System.out.println("How Many Kilo Cauliflower You Want");
                        qty = sc.nextLine();
                        Cauliflower.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Cauliflower);
                        }
                        break;
                    }
                    case "10" : {
                        Product Broccoli = new Veggies("BROCCOLI", "VEGETABLE", 60, 0);
                        System.out.println("How Many Kilo Broccoli You Want");
                        qty = sc.nextLine();
                        Broccoli.setProductQty(Integer.parseInt(qty));
                        System.out.println("Add To Cart");
                        addCart = sc.nextLine().toUpperCase();
                        if (addCart.equals("Y")) {
                            cart.addToCart(Broccoli);
                        }
                        break;
                    }
                    default : {
                        System.out.println("Product Not Available");
                        break;
                    }
                }
            System.out.println("Continue Buy Other Vegetables");
            repeat = sc.nextLine().toUpperCase();
        } while (repeat.equals("Y"));
    }

    public static void cartSection(){
        System.out.println("-".repeat(35));
        System.out.println("Product Details"+ "\t\t\t\tQTY" );
        for (Object o : cart.cart()) {
            Product product = (Product) o;
            System.out.println("-".repeat(35));
            System.out.println(product.getProductName() + "\n\t\t\t\t\t\t\t" + product.getProductQty() + "\n"+ product.getProductTotalPrice()+".Rs");
            Total = Total + product.getProductTotalPrice();
        }
        System.out.println("-".repeat(35));
        System.out.println("Your Total Bill is : " + Total + " Rs.");
        System.out.println("-".repeat(35));

    }
}
