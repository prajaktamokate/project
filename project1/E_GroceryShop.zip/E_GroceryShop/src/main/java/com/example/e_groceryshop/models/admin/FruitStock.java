package com.example.e_groceryshop.models.admin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FruitStock {
    ResultSet resultSet = null;

    public void addFruit(Statement statement, Fruits fruit)
    {
        int ID = 0;
        try{
            resultSet = statement.executeQuery("SELECT FRT_ID FROM FRUITS");
            while (resultSet.next())
            {
                ID = resultSet.getInt(1);
            }
            ID++;

//            statement.executeQuery("INSERT INTO FRUITS VALUES ("+ID+",'"+fruit.getFrtName()+"',"+fruit.getNewStock()+","+fruit.getFrtPrice());
            statement.executeQuery("INSERT INTO FRUITS VALUES ("+ID+",'"+fruit.getFrtName()+"',"+fruit.getNewStock()+","+fruit.getFrtPrice()+")");

        } catch (SQLException e) {
            System.out.println("New Fruit Not Stored in Database");
        }
        finally {
            try {
                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                System.out.println("Fruit Add Connection Not Closed");
            }
        }
    }
}
