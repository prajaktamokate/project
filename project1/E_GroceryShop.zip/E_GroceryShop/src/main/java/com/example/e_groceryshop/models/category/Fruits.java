package com.example.e_groceryshop.models.category;

public class Fruits extends Product {
    public Fruits(String productName, String productType, int productPrice, int productQty) {
        super(productName, productType, productPrice, productQty);
    }

}



