package com.example.e_groceryshop.models.address;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
@Embeddable
public class Address implements Serializable {

    private String flatNo;
    private String street;
    private String city;
    private String pinCode;

    public Address()
    {
        this("null","null","null","null");
    }

    public Address(String flatNo, String street, String city, String pinCode)
    {
        this.flatNo = flatNo;
        this.street = street;
        this.city = city;
        this.pinCode = pinCode;
    }

    public String getFlatNo() {
        return flatNo;
    }

    public void setFlatNo(String flatNo) {
        this.flatNo = flatNo;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    @Override
    public String toString() {
        return "address.Address{" +
                "flatNo = " + flatNo +
                ", street = " + street +
                ", city = " + city +
                ", pinCode = " + pinCode;
    }
}
