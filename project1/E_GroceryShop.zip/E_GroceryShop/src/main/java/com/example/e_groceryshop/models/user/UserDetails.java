package com.example.e_groceryshop.models.user;

import com.example.e_groceryshop.models.address.Address;
import com.sun.istack.NotNull;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "User_Details_Table",uniqueConstraints = {@UniqueConstraint(name = "uc_User_info",columnNames = {"email"})})
public class UserDetails implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "userGen")
    @SequenceGenerator(name = "userGen", allocationSize = 1)
    private int id;
    @NotNull
    private String firstName;
    @NotNull
    private String lastName;
    @NotNull
    private String mobileNo;
    @NotNull
    private String email;
    @NotNull
    private String password;
    private Address address;

    public UserDetails()
    {
        this("null","null","Null","null","null",null);
    }

    public UserDetails(String firstName, String lastName, String mobileNo, String email, String password, Address address)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNo = mobileNo;
        this.email = email;
        this.password = password;
        this.address = address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
    @Override
    public String toString() {
        return " UserDetails { " +
                "firstName = " + firstName +
                ", lastName = " + lastName +
                ", mobileNo = " + mobileNo +
                ", email = " + email +
                ", password = " + password +
                ", address = " + address + " }\n";
    }
}
