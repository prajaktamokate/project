package com.example.e_groceryshop.models.category;

public class Veggies extends Product {
    public Veggies(String productName, String productType, int productPrice, int productQty) {
        super(productName, productType, productPrice, productQty);
    }
}

