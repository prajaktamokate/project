package com.example.e_groceryshop.services.login;
import com.example.e_groceryshop.persistance.database.User_DetailsDb;

public class LoginPage {
    private User_DetailsDb user_detailsDb = new User_DetailsDb();
    public LoginPage()
    {

    }
    public Boolean isUser(String userName, String password)
    {
        return user_detailsDb.isUser(userName,password);
    }
}
