package com.example.e_groceryshop.models.category;

import java.util.ArrayList;
import java.util.List;

public class Cart<T extends  Product> {
    private List<T> productList = new ArrayList<>();

    public void addToCart(T product)
    {
        productList.add(product);
    }

    public List cart()
    {
        return productList;
    }

    @Override
    public String toString() {
        return "Cart{" +
                "productList=" + productList +
                '}';
    }
}
